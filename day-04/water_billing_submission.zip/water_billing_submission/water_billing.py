"""
Community Water Consumption and Billing Management System
Reads water_readings.txt, validates records, calculates consumption and
progressive bills, classifies households, ranks the top five consumers
and writes billing_report.txt and errors.log.
"""


"""
1. Read all lines from water_readings.txt
2. Handle a missing file.
"""

def read_file(filename):
    records = []
    try:
        file = open(filename, "r", encoding="utf-8")
        line_number = 0
        for line in file:
            line_number = line_number + 1
            records.append((line_number, line.rstrip("\n\r")))
        file.close()
        return records, ""
    except FileNotFoundError:
        return [], "ERROR: The file '" + filename + "' was not found."
    except OSError as error:
        return [], "ERROR: The input file could not be read: " + str(error)
    
    

"""
1.Split and clean fields

2.store valid records in a dictionary.
    - Reject missing fields
    - duplicate meter numbers
    - non-numeric/negative readings
    - Log the reason for every rejection.

"""
def validate_records(file_records):
    households = {}
    errors = []
    meter_numbers = []

    for line_number, file_line in file_records:
        fields = file_line.split(",")

        if len(fields) != 5:
            errors.append("Line " + str(line_number) +
                          ": rejected - 5 Expected fields not found, Only " +
                          str(len(fields)) + " fields found.")
            continue

        meter = fields[0].strip()
        name = fields[1].strip()
        previous_text = fields[2].strip()
        current_text = fields[3].strip()
        area = fields[4].strip()

        # Check for missing values.
        if meter == "" or name == "" or previous_text == "" or \
           current_text == "" or area == "":
            errors.append("Line " + str(line_number) +
                          ": rejected - Fields Missing")
            continue

        # Check duplicate meter numbers.
        if meter in meter_numbers:
            errors.append("Line " + str(line_number) +
                          ": rejected - Duplicate meter number " + meter + ".")
            continue

        # Readings must contain numeric whole-number values.
        try:
            previous = int(previous_text)
            current = int(current_text)
        except ValueError:
            errors.append("Line " + str(line_number) +
                          ": rejected - Previous or Current reading is not numeric. Please double check")
            continue

        # Reject negative readings.
        if previous < 0 or current < 0:
            errors.append("Line " + str(line_number) +
                          ": rejected - Negative meter reading. Please double check")
            continue

        # The current reading cannot be lower than the previous reading.
        if current < previous:
            errors.append("Line " + str(line_number) +
                          ": rejected - Current reading is lower than previous reading.")
            continue

        meter_numbers.append(meter)

        
        households[meter] = {
            "name": name,
            "previous": previous,
            "current": current,
            "area": area
        }

    return households, errors




#Calculate each household’s monthly consumption in kL.


def calculate_consumption(household):
    
    consumption = household["current"] - household["previous"]
    return consumption



#Calculate bills using the three progressive tariff bands.

def calculate_bill(consumption):
    bill = 0.0

    # First 6 kL are free.
    if consumption <= 6:
        bill = 0.0

    # From above 6 kL up to 20 kL, charge R8.50 per kL.
    elif consumption <= 20:
        bill = (consumption - 6) * 8.50

    # Above 20 kL: charge the first 14 paid kL at R8.50,
    # then charge each additional kL at R12.00.
    else:
        bill = (14 * 8.50) + ((consumption - 20) * 12.00)

    return bill


#Classify each valid household as LOW, MODERATE or HIGH.

def classify_consumption(consumption):
    if consumption <= 20:
        return "LOW"
    elif consumption <= 50:
        return "MODERATE"
    else:
        return "HIGH"


# Manually ranking the top five

def five_households(households):
    remaining = []

    for meter in households:
        household = households[meter]
        consumption = calculate_consumption(household)
        remaining.append({
            "meter": meter,
            "name": household["name"],
            "area": household["area"],
            "consumption": consumption,
            "bill": calculate_bill(consumption)
        })

    top_five = []
    number_to_select = 5

    if len(remaining) < number_to_select:
        number_to_select = len(remaining)

    selection = 0
    while selection < number_to_select:
        highest_index = 0
        index = 1

        while index < len(remaining):
            if remaining[index]["consumption"] > \
               remaining[highest_index]["consumption"]:
                highest_index = index
            index = index + 1

        top_five.append(remaining[highest_index])
        remaining.pop(highest_index)
        selection = selection + 1

    return top_five


# Create the billing report "billing_report.txt"
def create_report(filename, households, top_five, rejected_count):
    report = open(filename, "w", encoding="utf-8")

    report.write("BILLING REPORT DETAILING WATER CONSUMPTION \n")
    report.write("=" * 93 + "\n")
    report.write("Meter | Household\t | Area\t | Previous | Current | Used (kL) | Category\t | Bill (R)\n")
    report.write("=" * 93 + "\n")

    accepted_count = 0
    low_count = 0
    moderate_count = 0
    high_count = 0
    total_consumption = 0
    total_billing = 0.0

    for meter in households:
        household = households[meter]
        consumption = calculate_consumption(household)
        category = classify_consumption(consumption)
        bill = calculate_bill(consumption)

        report.write(
            meter + " | " + household["name"] + " \t| " + household["area"] +
            " \t| " + str(household["previous"]) +
            " \t| " + str(household["current"]) +
            " \t| " + str(consumption) +
            " \t| " + category +
            " \t| R" + format(bill, ".2f") + "\n"
        )

        accepted_count = accepted_count + 1
        total_consumption = total_consumption + consumption
        total_billing = total_billing + bill

        if category == "LOW":
            low_count = low_count + 1
        elif category == "MODERATE":
            moderate_count = moderate_count + 1
        else:
            high_count = high_count + 1
    report.write("\n")
    report.write("=" * 90 + "\n")
    report.write("HIGHEST-CONSUMING HOUSEHOLDS\n")
    report.write("=" * 90 + "\n")
    rank = 1
    for household in top_five:
        report.write(
            str(rank) + ". " + household["meter"] + " - " +
            household["name"] + " (" + household["area"] + "): " +
            str(household["consumption"]) + " kL, Bill R" +
            format(household["bill"], ".2f") + "\n"
        )
        rank = rank + 1

    report.write("\n")
    report.write("=" * 90 + "")
    report.write("\nSUMMARY\n")
    report.write("=" * 90 + "\n")
    report.write("Accepted records: " + str(accepted_count) + "\n")
    report.write("Rejected records: " + str(rejected_count) + "\n")
    report.write("LOW households: " + str(low_count) + "\n")
    report.write("MODERATE households: " + str(moderate_count) + "\n")
    report.write("HIGH households: " + str(high_count) + "\n")
    report.write("Total consumption: " + str(total_consumption) + " kL\n")
    report.write("Total amount billed: R" + format(total_billing, ".2f") + "\n")
    report.close()

    return accepted_count, total_consumption, total_billing

# Create "errors.log" 
def error_log(filename, errors):
    log = open(filename, "w", encoding="utf-8")
    log.write("=" * 93 + "\n")
    log.write(" REJECTED WATER READINGS RECORDS\n")
    log.write("=" * 93 + "\n")

    if len(errors) == 0:
        log.write("No rejected records.\n")
    else:
        for error in errors:
            log.write(error + "\n")

    log.write("\nTotal rejected records: " + str(len(errors)) + "\n")
    log.close()
   

def main():
   
    input_filename = "water_readings.txt"
    report_filename = "billing_report.txt"
    error_filename = "errors.log"

    raw_records, file_error = read_file(input_filename)

    if file_error != "":
        print(file_error)
        return

    households, errors = validate_records(raw_records)
    top_five =five_households(households)

    accepted_count, total_consumption, total_billing = create_report(
        report_filename, households, top_five, len(errors)
    )
    error_log(error_filename, errors)

    print("COMMUNITY WATER BILLING SYSTEM")
    print("=" * 33)
    print("Water Records captured:\t", len(raw_records))
    print("Accepted Records:\t", accepted_count)
    print("Rejected Records:\t", len(errors))
    print("")
    print("Total Community Consumption:", total_consumption, "kL")
    print("Total Amount Billed: \tR" + format(total_billing, ".2f"))
    print("Billing report created:", report_filename)
    print("Error log created:", error_filename)
    print("\n" + "=" * 43)
    print("Top 5 Water Household Consumers:")
    print("=" * 43)
    rank = 1
    for household in top_five:
        print(str(rank) + ".", household["meter"], household["name"],
              "\t", household["consumption"], "kL\t R" +
            format(household["bill"], ".2f") )
        rank = rank + 1




# Start the program.
main()
